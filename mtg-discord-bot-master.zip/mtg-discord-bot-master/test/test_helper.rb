require 'minitest/autorun'
require_relative '../lib/mtg_bot'